REAL LINE 縦型ホーム画面 公開用素材

portrait.html → GitHub リポジトリのルートへ配置
assets/real-line-portrait-home.webp → リポジトリの assets フォルダへ配置

公開URL: https://suzukishigeo1110-crypto.github.io/real-line/portrait.html

現在の index.html、hub.html、world.html、battle.html などは上書きしません。
学習・ミッション・装備・庭の localStorage データを読み取り、変更しません。
背景に描かれたコイン・宝石・レベルはイラスト内の仮表示です。
「冒険に出る」は hub.html、学習バトルは genres.html にリンクします。

※ ZIP は GitHub にまだアップロードしていません。
